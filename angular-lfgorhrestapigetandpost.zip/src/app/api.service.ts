import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import 'rxjs/operator/map';
@Injectable()
export class ApiService {
response:any;
  constructor(private http:HttpClient) { }
createapi(newform){
  console.log("api create call"+newform.name);
return this.http.post('https://reqres.in/api/users',
{ "name": newform.name,
    "job": newform.job}
    );
}
userArray:any={};
retriveApi(id){
  console.log("api side"+id);
  return this.http.get('https://reqres.in/api/users/'+id);
}
}