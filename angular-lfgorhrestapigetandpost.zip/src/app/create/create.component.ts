import { Component, OnInit } from '@angular/core';
import {ApiService} from '../api.service';
@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
newform:any;
data:any;
  constructor(private apicall:ApiService) { }

  ngOnInit() {
  }
register(newform){
console.log(newform.value);
this.apicall.createapi(newform).subscribe(data =>
 {
   this.data =data;
   
   console.log(this.data);
   if(this.data){
alert("created at"+this.data.createdAt);
   }
   });

}

}